import React from 'react';
import { render, screen } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect';
import Loader from './src/components/Loader/Loader';

test('renders Новая задача message', () => {
//   render(<Loader/>);
  shallow(<Loader />);
//   const linkElement = screen.getByText(/Новая задача/i);
//   expect(linkElement).toBeInTheDocument();
});