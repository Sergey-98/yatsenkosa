import { Task } from '../types/types';

const url = 'http://localhost:3003/';

// console.log(getData(name));
// console.log(postData(data, url));

export async function getData(name: string) {
    try {
        const res = await fetch(url+name);
        if (res.ok) {
            const data = await res.json();
            console.log(data.tasks);
            return await data.tasks;
        } else {
            console.log('Статус запроса: ' + res.status);
        }
    }
    catch(err) {
        console.log(`Ошибка: ${err}`);
    }
}

export async function getDataWeather() {
    try {
        const res = await fetch("https://api.openweathermap.org/data/2.5/forecast?lat=51.475802&lon=45.898988&appid=6ec7db2cad41aecb83f56c63bca7fe00&cnt=20&units=metric&lang=ru");
        //   console.log(res);
        if (res.ok) {
            const data = await res.json();
            // console.log(data);
            return await data;
        }  else {
            console.log('Статус запроса: ' + res.status);
        }
    }
    catch(err) {
        console.log(`Ошибка: ${err}`);
    }
}

export async function getDataNowWeather() {
    try {
        const res = await fetch("https://api.openweathermap.org/data/2.5/weather?lat=51.475802&lon=45.898988&appid=6ec7db2cad41aecb83f56c63bca7fe00&units=metric&lang=ru");
        //   console.log(res);
        if (res.ok) {
            const data = await res.json();
            // console.log(data);
            return await data;
        }  else {
            console.log('Статус запроса: ' + res.status);
        }
    }
    catch(err) {
        console.log(`Ошибка: ${err}`);
    }
}
