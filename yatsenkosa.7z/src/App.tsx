// составь структуру приложения, которое объединяет nodejs и react

// import Clock from 'components/Clock/Clock';
import React, { useReducer, useState, useEffect } from 'react';
import { BrowserRouter } from 'react-router-dom';
// import Sheduler from './components/Sheduler/Sheduler';
import Auth from './components/Authentification/Auth/Auth';
import { Context } from './Context/Context';
import { reducer, reducerMain } from 'reducer/reducer';
import { getLocalStorage, getAuth } from 'utils/localStorage';
import { getData } from './API/API';
import Loader from './components/Loader/Loader';
// import { Task } from './types/types';
// import Dev from './components/div/div';
import './styles/App.css';
import AppRouter from 'router/AppRouter';
import Header from 'components/Header/Header';

function App() {
  console.log(getAuth('isAuth'));
  const [isBurger, setIsBurger] = useState(false);
  const [loading, setLoading] = useState(true);
  const [isAuth, setIsAuth] = useState<boolean>(getAuth('isAuth'));
  const initialTasks = getLocalStorage('Tasks');
  

  // const initialTasks = getData('Sergey');
  // console.log(isAuth);
  console.log(getData('Sergey'));

  const initial = initialTasks && initialTasks.length > 0 ? initialTasks : [
    {
      TaskTitle: 'Новая задача',
      Status: 'waiting',
      TimeStart: '',
      TimeEnd: '',
      Description: 'Описание',
      isCheck: false,
    },
    {
      TaskTitle: 'Задача активна',
      Status: 'inProcess',
      TimeStart: '',
      TimeEnd: '',
      Description: 'Описание',
      isCheck: false,
    },
    {
      TaskTitle: 'Закрытая задача',
      Status: 'closed',
      TimeStart: '',
      TimeEnd: '',
      Description: 'Описание',
      isCheck: false,
    }
  ];

  const initAdd = false;

  const [tasks, dispatch] = useReducer(reducer, initial);
  const [isAddtask, dispatchTask] = useReducer(reducerMain, initAdd);

  useEffect(() => {
    setTimeout(() => setLoading(false), 5000);
  }, []);

  return (
    <Context.Provider value={{ tasks, dispatch, isAddtask, dispatchTask, isBurger, setIsBurger}}>
      {
        !isAuth ? <Auth isAuth={isAuth} setIsAuth={setIsAuth}/> : loading ? <Loader/> : <BrowserRouter>
        {/* <h1>Загрузка</h1> */}
        <Header />
        <AppRouter />
        {/* <Footer /> */}
      </BrowserRouter>
        // loading ? <h1>Загрузка</h1> : <Sheduler/>
      }
    </Context.Provider>
  );
}

export default App;