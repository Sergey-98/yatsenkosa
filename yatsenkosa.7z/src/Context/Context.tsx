import React, { Dispatch, SetStateAction } from 'react';
import { Task, DispatchType, DispatchTypeTask } from '../types/types';

type PropsP = {
    tasks: Task[];
    dispatch: Dispatch<DispatchType>;
    isAddtask: boolean;
    dispatchTask: Dispatch<DispatchTypeTask>;
    isBurger: boolean;
    setIsBurger: Dispatch<SetStateAction<boolean>>;
};

export const Context = React.createContext<PropsP>({
  tasks: [],
  dispatch: () => {},
  isAddtask: false,
  dispatchTask: () => {},
  isBurger: false,
  setIsBurger: () => {},
});