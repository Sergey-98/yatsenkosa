import React, { useState, useRef, useContext, Dispatch, SetStateAction } from 'react';
import style from './Auth.module.css';
import { Context } from '../../../Context/Context';
import data from '../../../data/data.json';
import { User } from 'types/types';
import { setLocalStorage } from 'utils/localStorage';

function Auth(props: {isAuth: boolean, setIsAuth: Dispatch<SetStateAction<boolean>>}) {
    const login = useRef<HTMLInputElement | null>(null);
    const password = useRef<HTMLInputElement | null>(null);
    const [isError, setIsError] = useState(false);

    function checkPassword() {
      const log_val = login.current?.value;
      const pass_val = password.current?.value;
      // console.log(log_val, pass_val);
      // tasks.filter((el: Task) => el.TaskTitle !== title || el.Status !== status);
      const checkUser_arr = data.users.filter((el : User) => el.login == log_val && el.password == pass_val);
      if (checkUser_arr.length == 1) {
        props.setIsAuth(true);
        setLocalStorage('isAuth', true);
        setIsError(false);
      } else {
        props.setIsAuth(false);
        setLocalStorage('isAuth', false);
        setIsError(true);
      }
    }

  return (
    <div className={style.auth_wrapper}>
      <input className={style.login_input} type="text" placeholder="Логин" ref={login}/>
      <input className={style.password_input} type="password" placeholder="Пароль" ref={password}/>
      <input className={style.submit_input} type="submit" onClick={checkPassword}/>
      {isError ? <p className={style.mistake}>Ошибка логина или пароля</p> : null}
    </div>
  );
}

export default Auth;