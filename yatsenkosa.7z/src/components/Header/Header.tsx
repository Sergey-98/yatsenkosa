import React, { useContext, useEffect, useState } from 'react';
import { NavLink } from 'react-router-dom';
import './Header.css';
import { Context } from '../../Context/Context';
import Hamburger from '../UI/Hamburger/Hamburger';

export default function Header() {
  const { isBurger, setIsBurger } = useContext(Context);

  const changeBurger = () => {
    if (isBurger) {
      setIsBurger(false);
    }
  };
  return (
    <header className="header">
      <nav className={isBurger ? 'navbar active' : 'navbar'}>
      {/* <nav className='navbar active'> */}
        <div className="navbar__links">
          <NavLink onClick={changeBurger} className="navbar__link" to="/Weather">
            Прогноз погоды
          </NavLink>
          <NavLink onClick={changeBurger} className="navbar__link" to="/Sheduler">
            Планировщик задач
          </NavLink>
        </div>
      </nav>
      <Hamburger />
    </header>
  );
}