import React, { useRef, useState, useContext, useEffect} from 'react';
import style from './AddTask.module.css';
import { Context } from '../../../Context/Context';

function AddTask() {

    const { tasks, dispatch, dispatchTask } = useContext(Context);

    const inputRef = useRef<HTMLInputElement | null>(null);
    const typeTask = useRef<HTMLSelectElement | null>(null);
    const descRef = useRef<HTMLTextAreaElement | null>(null);
    // const {typeTask, inputRef} = props;

    function addElem(typeTask: string, inputRef: React.RefObject<HTMLInputElement>): void {
        if (inputRef.current?.value) {
            dispatch({type: typeTask, payload:{TaskTitle: String(inputRef.current?.value), Status: typeTask, Description: String(descRef.current?.value)}});
            inputRef.current.value = '';
            dispatchTask({type: 'hide', payload: false});
        }
    }

    function closeModal() {
        dispatchTask({type: 'hide', payload: false});
    }

    return (
        <div className={style.wrapper_for_back}>
            <div className={style.add_task_wrapper}>
                <label>Выбрать тип задачи:</label>

                <select name="typeTasks" ref={typeTask}>
                    <option value="waiting">waiting</option>
                    <option value="inProcess">inProcess</option>
                    <option value="closed">closed</option>
                </select>

                <div className={style.block_inputs}>
                    <input className={style.task_input} type="text" ref={inputRef} placeholder="Заголовок"/>
                    <textarea className={style.description_input} ref={descRef} placeholder="Описание задачи"></textarea>
                </div>
                <div className={style.buttons_wrapper}>
                    <button className={style.shedule__add_button} onClick={() => addElem(String(typeTask.current?.value), inputRef)}>Добавить</button>
                    <button className={style.shedule__add_button} onClick={closeModal}>Отмена</button>
                </div>
            </div>
        </div>
    );
}

export default AddTask;