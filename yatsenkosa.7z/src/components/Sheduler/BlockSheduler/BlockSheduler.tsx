import React, { useContext } from 'react';
import BlockTask from '.././BlockTask/BlockTask';
import style from './BlockSheduler.module.css';
import { Task } from '../../../types/types';
import { Context } from '../../../Context/Context';

function BlockSheduler(props: {typeTask: string, inputRef: React.RefObject<HTMLInputElement>, descRef: React.RefObject<HTMLTextAreaElement>}) {

  const { tasks, dispatch } = useContext(Context);

  const {typeTask, inputRef, descRef} = props;

  const type = tasks.filter(task => task.Status == typeTask);

  function addElem(typeTask: string, inputRef: React.RefObject<HTMLInputElement>): void {
      if (inputRef.current?.value) {
          dispatch({type: typeTask, payload:{TaskTitle: String(inputRef.current?.value), Status: typeTask, Description: String(descRef.current?.value)}});
          inputRef.current.value = '';
      }
  }

  function changeTitle(title: string) {
    switch(title) {
      case 'waiting':
        return 'Нужно сделать'
      case 'inProcess':
        return 'В работе'
      case 'closed':
        return 'Выполнено'
    }
  }

  return (
    // type.length > 0 ?
    //   <div className={style.block_shedule_wrapper}>
    //     <div className={style.title_shedule}>{changeTitle(props.typeTask)}</div>
    //     <BlockTask arr={type}/>
    //   </div>
    //   : null
    <div className={style.block_shedule_wrapper}>
        <div className={style.title_shedule}>{changeTitle(props.typeTask)}</div>
        <BlockTask arr={type}/>
        {/* <input className={style.shedule_input} type="text" placeholder='Введите текст задачи' ref={inputRef}/>
        <button className={style.shedule__add_button} onClick={() => addElem(typeTask, inputRef)}>Добавить</button> */}
      </div>
  );
}

export default BlockSheduler;