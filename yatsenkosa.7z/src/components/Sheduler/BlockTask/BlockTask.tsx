import React, { useRef, useState, useEffect } from 'react';
import style from './BlockTask.module.css';
import { Task }  from '../../../types/types';
import OneTask from '../OneTask/OneTask';

function BlockTask(props: {arr: Task[]}) {
  return (
    <div className={style.blocks_wrapper}>
        {props.arr.map((el,id) => {
            return(
            <div key={id} className={style.block_wrapper}>
              <OneTask Task={el}/>
            </div>
        )})}
    </div>
  );
}

export default BlockTask;