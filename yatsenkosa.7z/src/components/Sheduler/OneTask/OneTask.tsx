import React, { useRef, useState, useContext, useEffect} from 'react';
import style from './OneTask.module.css';
import { Task }  from '../../../types/types';
import { Context } from '../../../Context/Context';

function OneTack(props: {Task: Task}) {

  const [isEdit, setIsEdit] = useState(false);
  const [val, setVal] = useState<Task | null>(null);
  const inputRef = useRef<HTMLInputElement | null>(null);
  const descRef = useRef<HTMLTextAreaElement | null>(null);
  const { dispatch} = useContext(Context);
  useEffect(() => {
    setVal(props.Task);
    inputRef.current ? inputRef.current.value = props.Task.TaskTitle : null;
    descRef.current ? descRef.current.value = props.Task.Description : null;
  });

  function changeCard() {
    setIsEdit(isEdit ? false : true);
    if (isEdit) {
      setVal({TaskTitle: String(inputRef.current?.value), Status: props.Task.Status, Description: String(descRef.current?.value)});
      dispatch({type: props.Task, payload:{TaskTitle: String(inputRef.current?.value), Status: props.Task.Status, Description: String(descRef.current?.value)}});
    }
  }

  function changeStatusCard(st: string) {
    setVal({TaskTitle: String(inputRef.current?.value), Status: String(st), Description: String(descRef.current?.value)});
    dispatch({type: props.Task, payload:{TaskTitle: String(inputRef.current?.value), Status: String(st), Description: String(descRef.current?.value)}});
  }

  function removeCard() {
    dispatch({type: 'remove', payload: {TaskTitle: String(inputRef.current?.value), Status: props.Task.Status, Description: String(descRef.current?.value)}});
  }

  // debugger;
  return (
    <div className={style.block_wrapper}>
      <div className={style.block_inputs}>
        <input className={isEdit ? style.task_input_active : style.task_input} type="text" defaultValue={val?.TaskTitle} ref={inputRef} readOnly={!isEdit}/>
        <textarea className={isEdit ? style.description_input_active : style.description_input} defaultValue={val?.Description} ref={descRef} readOnly={!isEdit} placeholder="Описание задачи"></textarea>
      </div>
      <div className={style.block_buttons}>
        <button className={style.button_card} onClick={changeCard}>{isEdit ? 'Сохранить' : 'Редактировать'}</button>
        {(['waiting'].indexOf(props.Task.Status) != -1) ? <button className={style.button_card} onClick={() => changeStatusCard('inProcess')}>В работу</button> : null}
        {(['inProcess'].indexOf(props.Task.Status) != -1) ? <button className={style.button_card} onClick={() => changeStatusCard('closed')}>Закрыть</button> : null}
        {(['closed'].indexOf(props.Task.Status) != -1) ? <button className={style.button_card} onClick={() => changeStatusCard('waiting')}>Открыть</button> : null}
        <button className={style.button_card} onClick={removeCard}>Удалить</button>
      </div>
    </div>
  );
}

export default OneTack;