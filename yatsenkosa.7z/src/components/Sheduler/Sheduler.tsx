import React, { useRef, useContext  } from 'react';
import style from './Sheduler.module.css';
import BlockSheduler from './BlockSheduler/BlockSheduler';
import { Context } from '../../Context/Context';
import AddTask from './AddTask/AddTask';

function Sheduler() {
    const { isAddtask, dispatchTask } = useContext(Context);

    const waitTaskTitle = useRef<HTMLInputElement | null>(null);
    const processTaskTitle = useRef<HTMLInputElement | null>(null);
    const closeTaskTitle = useRef<HTMLInputElement | null>(null);

    const waitTaskDescription = useRef<HTMLTextAreaElement | null>(null);
    const processTaskDescription = useRef<HTMLTextAreaElement | null>(null);
    const closeTaskDescription = useRef<HTMLTextAreaElement | null>(null);

    function showModal() {
      dispatchTask({type: 'show', payload: true});
    }

  return (
    <div className={style.shedule_wrapper}>
      <h1 className={style.shedule_title}>Мои задачи</h1>
        <button className={style.shedule__add_button} onClick={showModal}>Создать задачу</button>
        {isAddtask ? <AddTask /> : null}
        <div className={style.shedule_blocks}>
          <BlockSheduler typeTask='waiting' inputRef={waitTaskTitle} descRef={waitTaskDescription}/>
          <BlockSheduler typeTask='inProcess' inputRef={processTaskTitle} descRef={processTaskDescription}/>
          <BlockSheduler typeTask='closed' inputRef={closeTaskTitle} descRef={closeTaskDescription}/>
        </div>
    </div>
  );
}

export default Sheduler;