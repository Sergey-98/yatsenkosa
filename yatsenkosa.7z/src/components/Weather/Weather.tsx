import React, { useContext, useState } from 'react';
import style from './Weather.module.css';
import { Result, NowResult, List } from '../../types/typesWeather';
import Slider from './WeatherComponents/Slider/Slider';
import CardTemp from './WeatherComponents/CardTemp/CardTemp';
import { getAuth, getLocalStorage } from 'utils/localStorage';
import { getDataWeather, getDataNowWeather } from '../../API/API';

function Weather() {
    const [isUpdate, setIsUpdate] = useState(true);
    const [res, setRes] = useState<Result|null>(null);
    const [nowRes, setNowRes] = useState<NowResult|null>(null);
    const initialMessages = getLocalStorage('Messages');

    // console.log(getData('Sergey'));
    if (isUpdate) {
        (async function get() {
        const result = await getDataWeather();
        const nowResult= await getDataNowWeather();
        // console.log(result);
        setRes(result);
        setNowRes(nowResult);
        setIsUpdate(false);
        // console.log('Полученные данные:', result);
        return false;
        })();
    }

    const data = res;
    const nowData = nowRes;
    console.log(data);
    console.log(nowData);
    const city = data?.city;
    const cnt = data?.cnt;
    const cod = data?.cod;
    const list = data?.list;

    function getWindDirection(degrees:number) {
        const directions = [
            "Север", "Северо-Восток", "Восток", "Юго-Восток",
            "Юг", "Юго-Запад", "Запад", "Северо-Запад"
        ];

        const index = Math.round(degrees / 45) % 8;
        return directions[index];
    }

    function formatDate(dateString:string) {
        const [year, month, day] = dateString.split('-').map(String);
        return `${day}.${month}`;
        // return `${day}.${month}.${year}`;
    }

    function getTimeToTimezone(time: string) {
        const [hours, minutes, seconds] = time.split(':').map(Number);
        let zone = 0;
        if (city?.timezone) {
            zone = city?.timezone/3600;
        }
        let newHours = hours + zone;

        if (newHours > 23) {
          newHours -= 24;
        }
        const formattedHours = String(newHours).padStart(2, '0');
        const formattedMinutes = String(minutes).padStart(2, '0');
        const formattedSeconds = String(seconds).padStart(2, '0');
        return `${formattedHours}:${formattedMinutes}`;
    }

    function unixToDateTime(unixTime:number|undefined) {
        // Создаем объект Date на основе Unix времени (в миллисекундах)
        unixTime = unixTime?unixTime:0;
        const date = new Date(unixTime * 1000);
        // Форматируем дату и время
        const year = date.getFullYear();
        const month = String(date.getMonth() + 1).padStart(2, '0'); // Месяцы в JS начинаются с 0
        const day = String(date.getDate()).padStart(2, '0');
        const hours = String(date.getHours()).padStart(2, '0');
        const minutes = String(date.getMinutes()).padStart(2, '0');
        const seconds = String(date.getSeconds()).padStart(2, '0');
        // Возвращаем отформатированную строку
        // return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
        return `${year}-${month}-${day} ${hours}:${minutes}`;
      }

      function hPaToMmHg(hPa: number) {
        // Коэффициент для перевода ГПа в мм рт. ст.
        const conversionFactor = 0.750062;
        // Вычисление значения в мм рт. ст.
        const mmHg = hPa * conversionFactor;
        return mmHg.toFixed(1);
    }

    const slides = list ? list.map((elem:List, id:number) => {
        return (
            <div className = {style.listElem_wrapper} key = {id+150}>
                <span>{formatDate(elem.dt_txt.split(' ')[0])}</span>
                <span>{getTimeToTimezone(elem.dt_txt.split(' ')[1])} </span>
                <span>Осадки: {elem.pop*100}%</span>
                <img src={"https://openweathermap.org/img/wn/" + elem.weather[0].icon + "@2x.png"} alt='img' width='100px' height='100px'/>
                <span>{Math.round(elem.main.temp)}°</span>
            </div>
        )
    }) : null;


  return (
    <div className={style.weather_wrapper}>
        <div className={style.weather_wrapper__top}>
            <div className={style.weather_wrapper__top_left}>
                <div className={style.weather_wrapper__top_location}>
                    {city?.name}
                </div>
                <div className={style.weather_wrapper__top_date}>
                    {unixToDateTime(nowData?.dt).split(' ')[1]}
                </div>
                <div className={style.weather_wrapper__top_main_temp}>
                    <img src={"https://openweathermap.org/img/wn/" + nowData?.weather[0].icon + "@2x.png"} alt='img' className={style.weather_wrapper__top_main_temp_icon} width='100px' height='100px'/>
                    <div className={style.weather_wrapper__top_main_temp_wrapper}>
                        <div className={style.weather_wrapper__top_main_temp_value}>
                            {nowData ? Math.round(nowData?.main.temp) : null}°
                        </div>
                        <div className={style.weather_wrapper__top_main_temp_description}>
                            {nowData ? nowData?.weather[0].description : null}
                        </div>
                    </div>
                </div>
            </div>
            {
                nowData && list ?
                    <div className={style.weather_wrapper__top_right}>
                        <CardTemp value={String(Math.round(nowData?.main.temp_max))+'°'} description='Максимальная температура'/>
                        <CardTemp value={String(nowData?.wind.speed + ' м/с')} description='Скорость ветра'/>
                        <CardTemp value={String(unixToDateTime(nowData.sys.sunrise).split(' ')[1])} description='Восход'/>

                        <CardTemp value={String(Math.round(nowData?.main.temp_min))+'°'} description='Минимальная температура'/>
                        <CardTemp value={String(getWindDirection(nowData.wind.deg))} description='Направление ветра'/>
                        <CardTemp value={String(unixToDateTime(nowData.sys.sunset).split(' ')[1])} description='Закат'/>

                        <CardTemp value={String(Math.round(nowData?.main.feels_like))+'°'} description='Ощущается'/>
                        <CardTemp value={String(Number(list[0].pop*100) + '%')} description='Осадки'/>
                        <CardTemp value={String(hPaToMmHg(nowData?.main.grnd_level)+' мм.рт.ст.')} description='Давление'/>
                    </div>
                : null
            }
        </div>
        <div className={style.weather_wrapper__bottom}>
            <Slider items={slides} list = {list} />
        </div>
    </div>
  );
}

export default Weather;