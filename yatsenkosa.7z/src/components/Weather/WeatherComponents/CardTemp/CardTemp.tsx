import React, { useState, useEffect } from 'react';
import style from './CardTemp.module.css';
import { NowResult } from 'types/typesWeather';

function CardTemp(props:{value: string, description: string}) {

    return (
        <div className={style.data_wrapper_card}>
            <span className={style.data_wrapper_card_value}>
                {props.value}
            </span>
            <span className={style.data_wrapper_card_text}>
                {props.description}
            </span>
        </div>
    );
}

export default CardTemp;