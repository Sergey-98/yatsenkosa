import React, { useState } from 'react';
import { List } from 'types/typesWeather';
import './Slider.css';

type Prop = {
    items: React.ReactElement<HTMLDivElement>[] | null,
    list: List[]|undefined
}

const Slider = ({ items, list }:Prop) => {
    const [currentIndex, setCurrentIndex] = useState(0);

    const handlePrev = () => {
        setCurrentIndex((prevIndex) => (prevIndex === 0 && items ? items.length - 1 : prevIndex - 1));
    };

    const handleNext = () => {
        setCurrentIndex((prevIndex) => (items && prevIndex === items.length - 1 ? 0 : prevIndex + 1));
    };

    function formatDate(dateString:string) {
        const [year, month, day] = dateString.split('-').map(String);
        return `${day}.${month}.${year}`;
    }

    function getTimeToTimezone(time:string) {
        const [hours, minutes, seconds] = time.split(':').map(Number);
        const zone = 4;

        let newHours = hours + zone;

        if (newHours > 23) {
          newHours -= 24;
        }
        const formattedHours = String(newHours).padStart(2, '0');
        const formattedMinutes = String(minutes).padStart(2, '0');
        const formattedSeconds = String(seconds).padStart(2, '0');
        return `${formattedHours}:${formattedMinutes}:${formattedSeconds}`;
    }

    return (
        <div className="slider-container">
            <button className="slider-button prev" onClick={handlePrev}>
            <svg width="100" height="100" viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg">
                <line x1="20" y1="50" x2="80" y2="50" stroke="rgb(179, 179, 179)" strokeWidth="3.5"/>
                <line x1="20" y1="50" x2="50" y2="70" stroke="rgb(179, 179, 179)" strokeWidth="3.5"/>
                <line x1="20" y1="50" x2="50" y2="30" stroke="rgb(179, 179, 179)" strokeWidth="3.5"/>
            </svg>
            </button>
            <div className="slider-content">
                {items ? items.map((item:React.ReactElement<HTMLDivElement> | null, index:number) => (
                    <div key={index} className="slider-item" style={{ transform: `translateX(${currentIndex * -77}%)` }}>
                        <span className="slider-item-count">{index+1}</span>
                        {item}
                    </div>
                )) : null}
            </div>
            <button className="slider-button next" onClick={handleNext}>
            <svg width="100" height="100" viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg">
                <line x1="20" y1="50" x2="80" y2="50" stroke="rgb(179, 179, 179)" strokeWidth="3.5"/>
                <line x1="80" y1="50" x2="50" y2="30" stroke="rgb(179, 179, 179)" strokeWidth="3.5"/>
                <line x1="80" y1="50" x2="50" y2="70" stroke="rgb(179, 179, 179)" strokeWidth="3.5"/>
            </svg>
            </button>
        </div>
    );
};

export default Slider;