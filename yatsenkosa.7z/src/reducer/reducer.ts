import { Task, DispatchType, DispatchTypeTask } from '../types/types';
import { setLocalStorage } from 'utils/localStorage';

export function reducer(tasks: Task[], action: DispatchType) {
    // console.log(action);
    if (typeof action.type == 'object') {
      const title = action.type?.TaskTitle;
      // console.log(tasks.filter((el: Task) => el.TaskTitle == title));
      const editTask = tasks.filter((el: Task) => el.TaskTitle == title)[0];
      // console.log(editTask);
      editTask.TaskTitle = action.payload.TaskTitle;
      editTask.Status = action.payload.Status;
      editTask.Description = action.payload.Description;
      // console.log(editTask);
      setLocalStorage('Tasks', [...tasks]);
      return [...tasks];
    } else {
      switch (action.type) {
        case 'waiting':
            tasks.push(action.payload);
            setLocalStorage('Tasks', [...tasks]);
          return [
            ...tasks
          ];
        case 'inProcess':
            tasks.push(action.payload);
            setLocalStorage('Tasks', [...tasks]);
        return [
            ...tasks
          ];
        case 'closed':
            tasks.push(action.payload);
            setLocalStorage('Tasks', [...tasks]);
        return [
            ...tasks
          ];
        case 'remove':
          const title = action.payload?.TaskTitle;
          const status = action.payload?.Status;
          const description = action.payload?.Description;
          tasks = tasks.filter((el: Task) => el.TaskTitle !== title || el.Status !== status || el.Description != description);
            setLocalStorage('Tasks', [...tasks]);
        return [
          ...tasks
        ];
        default:
          setLocalStorage('Tasks', [...tasks]);
          return tasks;
      }
    }
  
}

export function reducerMain(isShow: boolean, action: DispatchTypeTask) {
  switch (action.type) {
    case 'show':
        isShow = true;
      return isShow;
    case 'hide':
      isShow = false;
      return isShow;
    default:
      return isShow;
  }
}