import Sheduler from "components/Sheduler/Sheduler";
import Weather from "components/Weather/Weather";

export const routes = [
    // { path: '/', component: Main },
    { path: '/Sheduler', component: Sheduler },
    { path: '/Weather', component: Weather },
    // { path: '*', component: Error },
  ];