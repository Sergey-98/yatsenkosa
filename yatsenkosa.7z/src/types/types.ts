export type Props = {
    children?: React.ReactNode;
    placeholder?: React.ReactNode;
    onClick?: () => void;
  };

export type DispatchType = {
  type?: string | Task | null;
  payload: Task;
};

export type DispatchTypeTask = {
  type?: string | null;
  payload: boolean;
};

export type DispatchTaskType = {
  type?: Task | null;
  payload: Task;
};

export type Task = {
  TaskTitle: string,
  Status: string,
  TimeStart?: string,
  TimeEnd?: string,
  Description: string,
  isCheck?: boolean
};

export type User = {
  login: string,
  password: string,
  name: string
}

