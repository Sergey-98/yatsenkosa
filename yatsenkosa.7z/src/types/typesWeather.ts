export type Props = {
    children?: React.ReactNode;
    placeholder?: React.ReactNode,
    onClick?: () => void;
  };

export type DispatchType = {
  type?: string | Task | null,
  payload: Task,
};

export type DispatchTaskType = {
  type?: Task | null,
  payload: Task,
};

export type Task = {
  TaskTitle: string,
  Status: string
};

export type User = {
  login: string,
  password: string,
  name: string
}

export type Message = {
  user: string,
  text: string
}

export type DispatchMessage = {
  type?: string | Message | null,
  payload: Message,
};
// ------------------------------------------------------
type Coord = {
  lon: number, // Географическое положение, долгота
  lat: number // Географическое положение, широта
};

type Weather = {
  id: number, // Идентификатор погодных условий
  main: string, // Группа погодных параметров (дождь, снег, облачность и т.д.)
  description: string, // Погодные условия в группе
  icon: string, // Идентификатор значка погоды
};

type Main = {
  temp: number, // Температура
  feels_like: number, // Температурный параметр учитывает восприятие человеком погодных условий
  temp_min: number, // Минимальная температура на момент расчёта
  temp_max: number, // Максимальная температура на момент расчёт
  temp_kf: number, // Внутренний параметр
  pressure: number, // Атмосферное давление на уровне моря по умолчанию, ГПа
  humidity: number, // Влажность, %
  sea_level: number, // Атмосферное давление на уровне моря, ГПа
  grnd_level: number, // Атмосферное давление на уровне земли, ГПа
}

type Wind = {
  speed: number, // Скорость ветра
  deg: number, // Направление ветра, градусы
  gust: number, // Порыв ветра
}

type Clouds = {
  all: number, // Облачность, %
}

type Sys = {
  pod: string // Часть дня (n - ночь, d - день)
}

type SysNow = {
  country: string,
  sunrise: number,
  sunset: number
}

type City = {
  coord: Coord, // Координаты
  country: string, //  Код страны
  id: number,  // Идентификатор города
  name: string, // Название города
  population: number, // Население города
  sunrise: number, // Время восхода солнца, Unix, UTC
  sunset: number, // Время захода солнца, Unix, UTC
  timezone: number, // Сдвиг в секундах от UTC
}

export type List = {
  clouds: Clouds, //
  dt: number, // Прогнозируемое время передачи данных, unix, UTC
  dt_txt: string, // Прогнозируемое время передачи данных, ISO, UTC
  main: Main,
  pop: number, // Вероятность выпадения осадков. Значения параметра варьируются от 0 до 1, где 0 соответствует 0%, а 1 — 100%
  sys: Sys, //
  visibility: string, // Средняя видимость, метров. Максимальное значение видимости составляет 10 км
  weather: Weather[],
  wind: Wind,
}

export type Result = {
  city: City,
  cnt: number, // Количество временных меток, возвращаемых в ответе API
  cod: string, // Внутренний параметр
  list: List[]
  message: number // Внутренний параметр
}

export type NowResult = {
  clouds: Clouds,
  main: Main,
  weather: Weather[],
  wind: Wind,
  sys: SysNow,
  name: string,
  cnt: number,
  cod: string, // Внутренний параметр
  dt: number, // Прогнозируемое время передачи данных, unix, UTC
}