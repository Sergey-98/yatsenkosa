export default function checkAuth (login: string, password: string) {
    
}