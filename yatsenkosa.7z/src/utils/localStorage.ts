import { Task } from '../types/types';

export const setLocalStorage = function (key: string, value: Task[] | boolean) {
    localStorage.setItem(key, JSON.stringify(value));
}

export const getLocalStorage = function (key: string):Task[]{
    return JSON.parse(localStorage.getItem(key) || '[]');
}

export const getAuth = function (key: string):boolean {
    return JSON.parse(localStorage.getItem(key) || 'false');
}